"""
FastAPI application for the FAIR Metadata Automation System.

This package contains the REST API implementation using FastAPI.
"""

__version__ = "1.0.0"
