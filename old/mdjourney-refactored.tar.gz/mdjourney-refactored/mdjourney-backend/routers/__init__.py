"""
API services for the FAIR Metadata Automation System.

This package contains API-specific service implementations.
"""

from .services import *
